""" Functions used in the periodic setting.
"""

import numpy as np
from pathlib import Path

from wavespin.tools import pathFinder as pf
from wavespin.tools import inputUtils as iu

def quantizationAxis(S,g_i,D_i,h_i):
    r""" Compute angles theta and phi of quantization axis depending on Hamiltonian parameters.
    Works for both uniform and site-dependent Hamiltonian parameters, where we take the average.
    In PBC each site has the same Q-axis, in OBC there could be border effects.

    Parameters
    ----------
    S : float, spin size.
    J,D,h : (Lx,Ly)-arrays of Hamiltonian parameters.

    Returns
    -------
    angles : 2-tuple.
        $\theta$,$\phi$ : polar and azimuthal angle.
    """
    if type(g_i[0]) in [float,int,np.float64]:   #if we give a single number for J1,J2,H etc.. -> static_dispersion.py
        g = g_i
        D = D_i
        h = h_i
    else:   #f we give a site dependent value of J1, J2 etc.., we need an average -> static_ZZ_*.py
        g = []
        D = []
        for i in range(2):
            if not (g_i[i] == np.zeros(g_i[i].shape)).all():
                g.append(abs(float(np.sum(g_i[i])/(g_i[i][np.nonzero(g_i[i])]).shape)))
            else:
                g.append(0)
            if not (D_i[i] == np.zeros(D_i[i].shape)).all():
                D.append(float(np.sum(D_i[i])/(D_i[i][np.nonzero(D_i[i])]).shape))
            else:
                D.append(0)
        if g[0]!=0:
            D[0] = D[0]/g[0]        #As we defined in notes
        if g[1]!=0:
            D[1] = D[1]/g[1]        #As we defined in notes
        if not (h_i == np.zeros(h_i.shape)).all():
            h_av = float(np.sum(h_i)/(h_i[np.nonzero(h_i)]).shape)
            h_stag = np.absolute(h_i[np.nonzero(h_i)]-h_av)
            h = float(np.sum(h_stag)/(h_stag[np.nonzero(h_stag)]).shape)
        else:
            h = 0
#    h_critical = 2*(g[0]*(1-D[0])-g[1]*(1-D[1]))
    h_critical = 4*g[0]*(1-D[0])
    if g[1]<g[0]/2 and h<h_critical:
        theta = np.arccos(h/h_critical)
    else:
        theta = 0
    #
    phi = 0
    angles = (theta, phi)
    return angles



