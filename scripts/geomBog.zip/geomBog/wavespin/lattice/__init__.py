""" Here we keep code defining the base class of our simulations, the lattice.
"""
