""" wavespin - A spin wave package for XY models

"""

# This file marks this directory as a python package.


