""" Plottings
"""

import numpy as np
import matplotlib.pyplot as plt
import math
import os
from pathlib import Path
from wavespin.tools import pathFinder as pf

def createFigure(n_subplots, subplotSize=(4, 4), plot3D=False, nRows=-1, nCols=-1):
    """Create a figure with n_subplots, keeping each subplot the same size.

    Parameters
    ----------
    n_subplots (int): number of subplots
    subplotSize (tuple): (width, height) of each subplot in inches
    """
    if nRows==-1 and nCols==-1: # choose rows and cols as close as possible to a square
        cols = math.ceil(math.sqrt(n_subplots)) if n_subplots!=10 else 5
        rows = math.ceil(n_subplots / cols) if n_subplots!=10 else 2
    else:
        cols = nCols
        rows = nRows

    fig, axes = plt.subplots(
        rows, cols,
        figsize=(cols * subplotSize[0], rows * subplotSize[1]),
        subplot_kw={"projection": "3d"} if plot3D else {}
    )

    # If only one subplot, axes is a single Axes object
    axes = axes.flatten() if isinstance(axes, (list, np.ndarray)) else [axes]

    return fig, axes, rows, cols

def plotWf3D(system,nModes=16):
    """ Here we plot just the wavefunctions (first n modes)
    """
    Lx = system.Lx
    Ly = system.Ly
    Ns = system.Ns
    U_ = system.U_
    V_ = system.V_
    X,Y = np.meshgrid(np.arange(Lx),np.arange(Ly),indexing='ij')
    phi = np.real(U_ - V_)
    for i in range(Ns):
        ix,iy = system._xy(i)
        phi[i,:] *= 2/np.pi*(-1)**(ix+iy+1)
    fig, axes, rows, cols = createFigure(nModes,plot3D=True)
    for n in range(nModes):
        ax = axes[n]
        if len(system.p.lat_offSiteList)==0:
            formattedPhi = phi[:,n].reshape(Lx,Ly)
        else:
            formattedPhi = np.zeros((Lx,Ly))
            for ix in range(Lx):
                for iy in range(Ly):
                    if (ix,iy) in system.offSiteList:
                        formattedPhi[ix,iy] = np.nan
                    else:
                        formattedPhi[ix,iy] = phi[system._idx(ix,iy),n]
        ax.plot_surface(X,Y,
                        formattedPhi,
                        cmap='plasma'
                        )
        ax.set_title("Mode: "+str(n))
    for ik in range(nModes,len(axes)):
        axes[ik].axis('off')
    plt.suptitle("Modes from bogoliubov transformation",size=20)
    plt.show()

def plotWf2D(system,nModes=25):
    """ Here we plot just the wavefunctions (first n modes)
    """
    Lx = system.Lx
    Ly = system.Ly
    Ns = system.Ns
    U_ = system.U_
    V_ = system.V_
    X,Y = np.meshgrid(np.arange(Lx),np.arange(Ly),indexing='ij')
    phi = system.awesome
    fig, axes, rows, cols = createFigure(nModes)
    for n in range(nModes):
        ax = axes[n]
        if len(system.p.lat_offSiteList)==0:
            formattedPhi = phi[:,n].reshape(Lx,Ly)
        else:
            formattedPhi = np.zeros((Lx,Ly))
            for ix in range(Lx):
                for iy in range(Ly):
                    if (ix,iy) in system.offSiteList:
                        formattedPhi[ix,iy] = np.nan
                    else:
                        formattedPhi[ix,iy] = phi[system._idx(ix,iy),n]
        ax.pcolormesh(X,Y,
                      formattedPhi,
                      cmap='bwr'
                      )
        ax.set_title("Mode: "+str(n))
        ax.set_aspect('equal')
    for ik in range(nModes,len(axes)):
        axes[ik].axis('off')
    plt.suptitle("Modes from bogoliubov transformation",size=20)
    fig.tight_layout()
    plt.show()

def plotWfCos(system,nModes=6):
    """ Here we plot the wavefunctions next to cosine functions (first n modes)
    """
    Lx = system.Lx
    Ly = system.Ly
    Ns = system.Ns
    U_ = system.U_
    V_ = system.V_
    X,Y = np.meshgrid(np.arange(Lx),np.arange(Ly))
    phi_ik = np.real(U_ - V_)
    for i in range(Ns):
        ix,iy = system.indexesMap[i]
        phi_ik[i,:] *= 2/np.pi*(-1)**(ix+iy+1)
    fig, axes, rows, cols = createFigure(nModes,plot3D=True,nRows=2,nCols=nModes)
    for ik in range(nModes):
        kx, ky = system._xy(ik)
        ax = axes[ik]
        ax.plot_surface(X,Y,
                        phi_ik[:,ik].reshape(Lx,Ly).T,
                        cmap='plasma'
                        )
        ax.set_title("Mode: "+str(ik))
        ax = axes[ik+nModes]
        kx, ky = extractMomentum(phi_ik[:,ik].reshape(Lx,Ly))
        ax.plot_surface(X,Y,
                        np.cos(np.pi*kx*(2*X+1)/(2*Lx))*np.cos(np.pi*ky*(2*Y+1)/(2*Ly)),
                        cmap='plasma'
                        )
        ax.set_title("Momentum: (%d,%d)"%(kx,ky))
    plt.suptitle("Comparison of modes and cosine functions",size=20)
    plt.show()



