""" Functions used for the open boundary conditions' calculations.
"""

import os
import scipy
import numpy as np
from pathlib import Path

from wavespin.lattice.lattice import latticeClass
from wavespin.tools import pathFinder as pf
from wavespin.tools import inputUtils as iu
from wavespin.static.periodic import quantizationAxis
from wavespin.plots.rampPlots import *
from wavespin.plots import fancyLattice

class openHamiltonian(latticeClass):
    def __init__(self, p: iu.myParameters):
        super().__init__(p)
        # Hamiltonian parameters
        self.g1,self.g2,self.d1,self.d2,self.h,self.h_disorder = self.p.dia_Hamiltonian
        self.S = 0.5     #spin value
        self.g_i = (self._NNterms(self.g1), self._NNNterms(self.g2))
        self.D_i = (self._NNterms(self.d1), self._NNNterms(self.d2))
        self.h_i = self._Hterms(self.h,self.h_disorder)
        # self.realSpaceHamiltonian = self._realSpaceHamiltonian()

    def _NNterms(self,val):
        """ Construct Ns,Ns matrix for real space Hamiltonian using the lattice nn.
        """
        vals = np.zeros((self.Ns,self.Ns))
        for i in range(self.Ns):
            vals[i,self.NN[i]] = val
        return vals

    def _NNNterms(self,val):
        """ Construct Ns,Ns matrix for real space Hamiltonian using the lattice nnn.
        """
        vals = np.zeros((self.Ns,self.Ns))
        for i in range(self.Ns):
            vals[i,self.NNN[i]] = val
        return vals

    def _Hterms(self,val,disorder_val):
        vals = np.zeros((self.Ns,self.Ns))
        disorder = (np.random.rand(self.Ns)-0.5)*2 * disorder_val
        for i in range(self.Ns):
            ix,iy = self._xy(i)
            vals[i,i] = (-1)**(ix+iy+1) * val + disorder[i]
        return vals

    def quantizationAxisAngles(self,verbose=False):
        """ Here we get the quantization axis angles to use for the diagonalization.
        Phi is 0, we would need it just when the dynamics is implemented.
        """
        self.theta, self.phi = quantizationAxis(self.S,self.g_i,self.D_i,self.h_i)
        self.phis = np.zeros(self.Ns)
        if self.p.dia_uniformQA:
            self.thetas = np.ones(self.Ns)*self.theta
            if 0:   # Plot solution
                kwargs = {'indices':False, 'angles':True}
                fancyLattice.plotSitesGrid(self,**kwargs)
                #exit()
        else:
            print("Non-uniform angles not implemented yet, change uniformQA option to True.")
            exit()

    def computeTs(self,order='c-Neel'):
        """ Compute the vector parameters t_z, t_x and t_y as in notes for sublattice A and B.
        Sublattice A has negative magnetic feld.
        """
        self.ts = np.zeros((self.Ns,3,3))
        if order=='c-Neel': #nn: A<->B, nnn: A<->A
            for i in range(self.Ns):
                ix,iy = self._xy(i)
                sign = (-1)**(ix+iy)
                th = self.thetas[i]
                ph = self.phis[i]
                self.ts[i,0] = sign*np.array([np.sin(th)*np.cos(ph),np.sin(th)*np.sin(ph),np.cos(th) ]) #t_zx,t_zy,t_zz
                self.ts[i,1] = sign*np.array([np.cos(th)*np.cos(ph),np.cos(th)*np.sin(ph),-np.sin(th)]) #t_xx,t_xy,t_xz
                self.ts[i,2] =      np.array([-np.sin(ph)          ,np.cos(ph)           ,0          ]) #t_yx,t_yy,t_yz

    def computePs(self,order='c-Neel'):
        """ Compute coefficient p_gamma^{alpha,beta}_ij for a given classical order.
        alpha,beta=0,1,2 -> z,x,y like for ts.

        Parameters
        ----------

        Returns
        -------
        """
        self.Ps = np.zeros((2,self.Ns,self.Ns,3,3))     # number of nearest-neighbor(2), Ns, Ns, zxy, xyz 
        vecGnn = np.array([self.g_i[0],self.g_i[0],self.g_i[0]*self.D_i[0]])        #3,Ns,Ns
        vecGnnn = np.array([self.g_i[1],self.g_i[1],self.g_i[1]*self.D_i[1]])
        if order=='c-Neel': #nn: A<->B, nnn: A<->A
            for i in range(self.Ns):
                #nn
                for j in self.NN[i]:
                    self.Ps[0,i,j] = np.einsum('d,ad,bd->ab',vecGnn[:,i,j],self.ts[i],self.ts[j],optimize=True)
                #nnn
                for j in self.NNN[i]:
                    self.Ps[1,i,j] = np.einsum('d,ad,bd->ab',vecGnnn[:,i,j],self.ts[i],self.ts[j],optimize=True)

    def _realSpaceHamiltonian(self,verbose=False):
        """
        Compute the real space Hamiltonian -> (2Ns x 2Ns).
        Conventions for the real space wavefunction and parameters are in the notes.
        SECOND NEAREST-NEIGHBOR: implemented Ps but not in the Hamiltonian.

        Returns
        -------
        ham : 2Ns,2Ns matrix of real space Hamiltonian.
        """
        S = self.S
        Ns = self.Ns
        g_i = self.g_i
        D_i = self.D_i
        h_i = self.h_i
        self.quantizationAxisAngles(verbose)
        self.computeTs()
        self.computePs()
        p_zz = self.Ps[0,:,:,0,0]
        p_xx = self.Ps[0,:,:,1,1]
        p_yy = self.Ps[0,:,:,2,2]
        #
        ham = np.zeros((2*Ns,2*Ns),dtype=complex)
        #p_zz sums over nn but is on-site -> problem when geometry is not rectangular
        ham[:Ns,:Ns] = abs(h_i)*np.cos(np.diag(self.thetas)) / 2 / S - np.diag(np.sum(p_zz,axis=1)) / 2 / S
        ham[Ns:,Ns:] = abs(h_i)*np.cos(np.diag(self.thetas)) / 2 / S - np.diag(np.sum(p_zz,axis=1)) / 2 / S
        #off_diag 1 - nn
        off_diag_1_nn = (p_xx+p_yy) / 4 / S
        ham[:Ns,:Ns] += off_diag_1_nn
        ham[Ns:,Ns:] += off_diag_1_nn
        #off_diag 2 - nn
        off_diag_2_nn = (p_xx-p_yy) / 4 / S
        ham[:Ns,Ns:] += off_diag_2_nn
        ham[Ns:,:Ns] += off_diag_2_nn.T.conj()
        return ham

    def diagonalize(self,verbose=False,**kwargs):
        """ Compute the Bogoliubov transformation for the real-space Hamiltonian.
        Initialize U_, V_ and evals : bogoliubov transformation matrices U and V and eigenvalues.
        """
        argsFn = ('bogWf',self.Lx,self.Ly,self.Ns,self.p.dia_Hamiltonian)
        transformationFn = pf.getFilename(*argsFn,dirname=self.dataDn,extension='.npz')
        hamiltonian = self._realSpaceHamiltonian(verbose)
        if not Path(transformationFn).is_file():
            if np.max(np.absolute(hamiltonian-hamiltonian.conj()))>1e-5:
                raise ValueError("Hamiltonian is not real! Procedure might be wrong")
            # Para-diagonalization
            Ns = self.Ns
            A = hamiltonian[:Ns,:Ns]
            B = hamiltonian[:Ns,Ns:]
            try:
                K = scipy.linalg.cholesky(A-B)
            except:
                K = scipy.linalg.cholesky(A-B+np.identity(Ns)*1e-4)
            lam2,chi_ = scipy.linalg.eigh(K@(A+B)@K.T.conj())
            if self.p.dia_excludeZeroMode:
                lam2[0] = 1
            self.evals = np.sqrt(lam2)         #dispersion -> positive
            #
            chi = chi_ / self.evals**(1/2)     #normalized eigenvectors: divide each column of chi_ by the corresponding eigenvalue -> of course for the gapless mode there is a problem here
            phi_ = K.T.conj()@chi
            psi_ = (A+B)@phi_/self.evals       # Problem also here
            self.U_ = 1/2*(phi_+psi_)
            self.V_ = 1/2*(phi_-psi_)
            self.awesome = np.real(self.U_ - self.V_)
            for i in range(self.Ns):
                ix,iy = self._xy(i)
                self.awesome[i,:] *= 2/np.pi*(-1)**(ix+iy+1)
            if self.p.dia_saveWf:
                if not Path(self.dataDn).is_dir():
                    print("Creating 'Data/' folder in directory: "+self.dataDn)
                    os.system('mkdir '+self.dataDn)
                np.savez(transformationFn,U=self.U_,V=self.V_,awesome=self.awesome,evals=self.evals)
        else:
            if verbose:
                print("Loading Bogoliubov transformation from file: "+transformationFn)
            self.U_ = np.load(transformationFn)['U']
            self.V_ = np.load(transformationFn)['V']
            self.awesome = np.load(transformationFn)['awesome']
            self.evals = np.load(transformationFn)['evals']

        if self.p.dia_excludeZeroMode:       #Put to 0 the eigenstate corresponding to the zero energy mode -> a bit far fetched
            self.U_[:,0] *= 0
            self.V_[:,0] *= 0
            self.awesome[:,0] *= 0
        if self.p.dia_plotWf:
            #plotWf3D(self)
            plotWf2D(self,nModes=25)
            #plotWfCos(self)
        if self.p.dia_plotMomenta:
            plotBogoliubovMomenta(self,**kwargs)










