""" A collection of usefool tools.

"""
