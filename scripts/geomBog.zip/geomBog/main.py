""" Script to compute and plot the Bogoliubov functions
Usage: python main.py input.txt
In input.txt you can change the geometry of the system, wheter to plot the lattice and/or to plot and save the functions.
In here you can chose the Hamiltonian parameters g and h.
h is still in the old convention so h*n_i, not h*Z_i -> value at beginning of the ramp is 15.
The result is saved in a *.npz file in the Data/ folder.
To get the awesome functions: np.load(filename.npz)['awesome']
To get the respective energies: np.load(filename.npz)['evals']
"""
import numpy as np
import sys, os, argparse
sys.path.append(os.path.dirname(os.path.dirname(__file__)))
from wavespin.tools.inputUtils import importParameters
from wavespin.static.open import openHamiltonian

""" Parameters and options """
parser = argparse.ArgumentParser(description="Static correlator calculation using Holstein-Primakoff formalism")
parser.add_argument("inputFile", help="Name of the file where computation parameters and options are stored")
parser.add_argument("-v","--verbose", help="Enable verbose output", action="store_true")
inputArguments = parser.parse_args()
verbose = inputArguments.verbose
parameters = importParameters(inputArguments.inputFile,**{'verbose':verbose})

""" Chose the parameters: g=10 and h=0 is XY phase """
g = 10
h = 0       # 15 to 0
parameters.dia_Hamiltonian = (g,0,0,0,h,0)
system = openHamiltonian(parameters)
system.diagonalize(verbose=verbose)

