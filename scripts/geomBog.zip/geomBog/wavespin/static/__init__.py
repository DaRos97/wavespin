""" Here we collect functions for computing properties of the ground state.
"""
