""" Plotting functions.

"""
